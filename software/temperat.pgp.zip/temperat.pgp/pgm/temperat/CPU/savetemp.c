
/** INCLUDE Files **/
#include <bur/plctypes.h> /** IEC datatypes **/
#include "dataobj.h"	  /**Data Objects Library **/
#include "loopcont.h"     /** LoopCont Library **/
#include "loopconr.h"     /** LoopConR Library **/
#include "sys_lib.h"     /** system lib **/
#include "asstring.h"     /** string lib **/
#include "Controler.h"     /** test**/


/** Variable declarations **/
_LOCAL  LCCounter_typ                baseLCCounter;
_LOCAL  LCPID_typ                    LCPID_0;
_LOCAL  LCPIDTune_typ                LCPIDTune_0;
_LOCAL  LCRSimModExt_typ             extruderLCRSimModExt;
_LOCAL  INT                          setValue, actValue, manipulatedVar;
_LOCAL  BOOL                         start;
_LOCAL  UDINT                        tuningRequest;
_LOCAL  lcpid_tune_addpar_typ        addParameter;
_LOCAL  lcpid_tune_osc_options_typ   oscOptions;
_LOCAL  lcpid_tune_step_options_typ  stepOptions;
_GLOBAL INT zoneNumber,i; 
_GLOBAL UINT status;
_LOCAL DatObjInfo_typ DatObjInfo_0;
_LOCAL DatObjCreate_typ	DatObjCreate_0;
_LOCAL DatObjWrite_typ	DatObjWrite_0;

/*one zone  */
_LOCAL Controler *controlers[80],controler1;
_GLOBAL INT  pidPar_p_1,
			 pidPar_i_1,
		     pidPar_d_1;
_LOCAL int save,saveIndex;
_LOCAL char *tmpStr1,*tmpStr;

_LOCAL int cnt,log;


/* ====== INIT Part ======= */
void _INIT temp1INIT(void)
{
	status = TMP_alloc(sizeof(char),(void**)&tmpStr1);
		if(status != 0)
              {
                 return;
              }
	status = TMP_alloc(sizeof(char),(void**)&tmpStr);
		if(status != 0)
              {
                 return;
              }

       if(zoneNumber == 0) 
       {
              zoneNumber=1;
       }
       
       /* Allocate the runtime memory for the defined zones*/
       for(i=0;i<zoneNumber;++i)
       {
              status = TMP_alloc(sizeof(Controler), (void**)&controlers[i]);
              if(status != 0)
              {
                     controlers[i] = 0;
                     return;
              }
              
              memset(controlers[i], 0, sizeof(Controler));
       }      
       
       /* We store the runtime memory to data object, so it will remain after power failure
       // First we check if the data object exists. If it is exists we copy from it to the runtime memory.
       // If it does not exists, we will create it.*/
       for(i=0;i<zoneNumber;++i)
       {
              /* Build the name of the data object as CtrDat_0, CtrDat_1, ... CtrDat_8*/
             itoa(i, tmpStr1);
              strcpy(tmpStr, "CtrDat_");
              strcat(tmpStr, tmpStr1);
              
              /* Check if it exist*/
              DatObjInfo_0.enable = 1;
			  DatObjInfo_0.pName = tmpStr;
              DatObjInfo(&DatObjInfo_0);
              
              if (DatObjInfo_0.status == ERR_OK)
              {
                     /* Data object exist. Copy it to the runtime memory*/
                     memcpy(controlers[i], DatObjInfo_0.pDatObjMem, sizeof(Controler));
                     ++log;
              }
              else /* Data object does not exists, we will create it now*/
              {
                     /* Create the data object*/
                     DatObjCreate_0.enable = 1;
                     DatObjCreate_0.grp = 0;
                     DatObjCreate_0.pName = tmpStr;
                     DatObjCreate_0.len = sizeof(Controler);
                     DatObjCreate_0.MemType = doUSRROM;
                     DatObjCreate_0.Option = 0;
                     DatObjCreate_0.pCpyData = controlers[i];
                     DatObjCreate(&DatObjCreate_0);
                     --log;

              }
       }

       save = 0;       /* Set to 1 to copy the runtime controlers to the data object (flash memory)*/
       saveIndex = 0;
}

void _CYCLIC temp1CYCLIC(void)
{
       /* Use controls[i] for manipulation of the process
       
       // If you want to store the runtime data to flash, set the save variable to 1*/
       if(zoneNumber == 0)
       	zoneNumber=1;
      
       
       if (save)
       {
              save = 0;
              saveIndex = 1;
       }
       
       /* We write one controler[i] in each cycle, so it will not cause a time violation*/
       if (saveIndex > 0)
       {
              i = saveIndex - 1;
              
              /* Build the data object name*/
              itoa(i, tmpStr1);
              strcpy(tmpStr, "CtrDat_");
              strcat(tmpStr, tmpStr1);
              
              /* Get the ident of the data object*/
              DatObjInfo_0.enable = 1;
              DatObjInfo_0.pName = tmpStr;
              DatObjInfo(&DatObjInfo_0);
              
              if (DatObjInfo_0.status == ERR_OK)
              {
                     /* Copy the controler[i] to the data object*/
                     DatObjWrite_0.enable = 1;
                     DatObjWrite_0.ident = DatObjInfo_0.ident;
                     DatObjWrite_0.Offset = 0;
                     DatObjWrite_0.pSource = controlers[i];
                     DatObjWrite_0.len = sizeof(Controler);
                     DatObjWrite(&DatObjWrite_0);
              }
       
              /* Increment to the next controler*/
              saveIndex++;
              
              /* Check if we save all controlers*/
              if (saveIndex > zoneNumber)
              {
                     /* We finish the save process*/
                     saveIndex = 0;
              }
       }
}














