
/** INCLUDE Files **/
#include <bur/plctypes.h> /** IEC datatypes **/
#include "loopcont.h"     /** LoopCont Library **/
#include "loopconr.h"     /** LoopConR Library **/
#include "sys_lib.h"     /** system lib **/
#include "asstring.h"     /** string lib **/
#include "Controler.h"    /** Controler + AutoTune**/
#include "Group.h"     	  /** group struct**/

#define SIZE	8

/** Variable declarations **/
_LOCAL  LCCounter_typ                baseLCCounter;
_LOCAL  LCPID_typ                    LCPID_0;
_LOCAL  LCPIDTune_typ                LCPIDTune_0;
_LOCAL  LCRSimModExt_typ             extruderLCRSimModExt[SIZE];
_LOCAL  INT                          setValue, actValue, manipulatedVar;
_LOCAL  BOOL                         start;
_LOCAL  UDINT                        tuningRequest;
_LOCAL  lcpid_tune_addpar_typ        addParameter;
_LOCAL  lcpid_tune_osc_options_typ   oscOptions;
_LOCAL  lcpid_tune_step_options_typ  stepOptions;
_LOCAL INT zoneNumber,i; 
_LOCAL UINT status_alloc;
_LOCAL UDINT adr;

_LOCAL Controler controlers[SIZE],controler1;
_LOCAL Group group[2];
/*one zone test */
_GLOBAL INT pidPar_p_1,pidPar_i_1,pidPar_d_1;
_GLOBAL INT setValue_0,actValue_0,sensorCorrection_0,highDeviation_0,lowDeviation_0,barrelDelayTime,mouldDelayTime,coolDelayTime;
_GLOBAL BOOL enable_0;
_GLOBAL UINT maxDiffTemp_0,maxDiffTemp_1,maxDiffTemp_2;
/*****VAR for loop********/
_LOCAL INT setValues[SIZE],actValues[SIZE],sensorCorrections[SIZE],lowDeviations[SIZE],highDeviations[SIZE];
_LOCAL INT groupTurnOn[5],groupTurnOff[5];
_LOCAL BOOL enables[SIZE];


/* ====== INIT Part ======= */
_INIT void initialization(void)
{


  /* Init variables */
  if(zoneNumber == 0)
  	zoneNumber=1;
 /*max temperature for group*/
  group[0].max_temperature = 3000;		/*barrel*/
  group[1].max_temperature = 3000;		/*mould*/
  group[2].max_temperature = 1000;		/*cooling*/
   
   /*min temparature for group*/
    group[0].min_temperature = 10;		/*barrel*/
  	group[1].min_temperature = 10;		/*mould*/
  	group[2].min_temperature = 10;		/*cooling*/
	
	/*cycle time for group*/
    group[0].setCycleTime = 100000;		/*barrel 100mSEC*/
  	group[1].setCycleTime = 10000;		/*mould 10mSEC*/
  	group[2].setCycleTime = 500000;		/*cooling 500mSEC*/
	
	/*delay time start count after all controllers are above low Deviation*/
    group[0].delayTime = barrelDelayTime;		/*barrel*/
  	group[1].delayTime = mouldDelayTime;		/*mould*/
  	group[2].delayTime = coolDelayTime;		/*cooling*/
	
	/*max difference between two zones*/
    group[0].maxDiffTemp = maxDiffTemp_0;		/*barrel*/
  	group[1].maxDiffTemp = maxDiffTemp_1;		/*mould*/
  	group[2].maxDiffTemp = maxDiffTemp_2;		/*cooling*/


	/*controllers configuration*/
	
	controlers[0].groupNum = 0;  /*controler 0 belong to group 0*/
	controlers[0].contType = 0;   /*controler 0 type is pid*/
  
    	
  	/* here should be a loop to Malloc memory acording to zoneNumber	*/
  	
 	for(i=0;i<zoneNumber;++i){
 /*  status_alloc = TMP_alloc(sizeof(Controler), (void**)&controlers[i]);
    if(status_alloc != 0) 
      controlers[i] = 0;	*/   
   tuningRequest = LCPID_TUNE_REQU_OFF;

  /* Parameters for PID tuning */
  controlers[i].autoTuneControler.Y_min = 0;
  controlers[i].autoTuneControler.Y_max = 32767;
  controlers[i].autoTuneControler.Y0    = 6300;
  controlers[i].autoTuneControler.Y1    = 11300;
  controlers[i].autoTuneControler.X0    = 250;
  controlers[i].autoTuneControler.X_min = -10000;
  controlers[i].autoTuneControler.X_max = 10000;
  controlers[i].autoTuneControler.P_manualAdjust = 0;
  controlers[i].autoTuneControler.I_manualAdjust = 0;
  controlers[i].autoTuneControler.D_manualAdjust = 0;
  controlers[i].autoTuneControler.pAddPar  = (lcpid_tune_addpar_typ*)&addParameter;
  controlers[i].autoTuneControler.pOptions_osc  = (lcpid_tune_osc_options_typ*)&oscOptions;
  controlers[i].autoTuneControler.pOptions_step  = (lcpid_tune_step_options_typ*)&stepOptions;

  /* Parameters for PID controller */
  controlers[i].controler.A        = 0;
  controlers[i].controler.Y_man    = 0;
  controlers[i].controler.Y_fbk    = 0;
  controlers[i].controler.hold_I   = 0;
  controlers[i].controler.out_mode = LCPID_OUT_MODE_AUTO;

	/* Parameters for extruder simulation model */
  extruderLCRSimModExt[i].enable   = 1;
  extruderLCRSimModExt[i].Tt_h     = 900000;	/* microseconds */
  extruderLCRSimModExt[i].Tt_c     = 500000;	/* microseconds */
  extruderLCRSimModExt[i].k_h      = 39;
  extruderLCRSimModExt[i].k_c      = 0.012;
  extruderLCRSimModExt[i].PT2_T1   = 5.0;
  extruderLCRSimModExt[i].PT2_T2   = 12.5;
  extruderLCRSimModExt[i].Temp_amb = 250;
  extruderLCRSimModExt[i].Temp_c   = 250;
  extruderLCRSimModExt[i].Alpha_c  = 0.0;

  } 
/*
  setValue      = 1000;
  start         = 0;
  tuningRequest = LCPID_TUNE_REQU_OFF;

  /* Parameters for PID tuning */
 /* controler1.autoTuneControler.Y_min = 0;
  controler1.autoTuneControler.Y_max = 32767;
  controler1.autoTuneControler.Y0    = 6300;
  controler1.autoTuneControler.Y1    = 11300;
  controler1.autoTuneControler.X0    = 250;
  controler1.autoTuneControler.X_min = -10000;
  controler1.autoTuneControler.X_max = 10000;
  controler1.autoTuneControler.P_manualAdjust = 0;
  controler1.autoTuneControler.I_manualAdjust = 0;
  controler1.autoTuneControler.D_manualAdjust = 0;
  controler1.autoTuneControler.pAddPar  = (lcpid_tune_addpar_typ*)&addParameter;
  controler1.autoTuneControler.pOptions_osc  = (lcpid_tune_osc_options_typ*)&oscOptions;
  controler1.autoTuneControler.pOptions_step  = (lcpid_tune_step_options_typ*)&stepOptions;

  /* Parameters for PID controller */
 /* controler1.controler.A        = 0;
  controler1.controler.Y_man    = 0;
  controler1.controler.Y_fbk    = 0;
  controler1.controler.hold_I   = 0;
  controler1.controler.out_mode = LCPID_OUT_MODE_AUTO;
	
	
  /* Parameters for extruder simulation model */
 /* extruderLCRSimModExt.enable   = 1;
  extruderLCRSimModExt.Tt_h     = 900000;	/* microseconds */
/*  extruderLCRSimModExt.Tt_c     = 500000;	/* microseconds */
/*  extruderLCRSimModExt.k_h      = 39;
  extruderLCRSimModExt.k_c      = 0.012;
  extruderLCRSimModExt.PT2_T1   = 5.0;
  extruderLCRSimModExt.PT2_T2   = 12.5;
  extruderLCRSimModExt.Temp_amb = 250;
  extruderLCRSimModExt.Temp_c   = 250;
  extruderLCRSimModExt.Alpha_c  = 0.0;*/
  
}

/* ======== CYCLIC Part ======= */
_CYCLIC void cyclicfunction(void)
{
/*============================================================================
                HEATING ORGANIZATION
  ============================================================================
***************************************************************

Function:  Heating Organisation
           Sensor Checking
           Tolerance checking
           Soft start
           Controller selection and optimization

Group numbers:   0  barrel  
                 1  mould heating
                 2  "cooling"
                
controlers[].enable:  	off
controlers[].contType 	0  heating PID
                 		1  heating PID for hotrunner (with soft start allowed)
                		2  open loop
                 		3: Autotuning
swoff_reason:    		1  max. temp. monitoring   (why a zone was switched off)
                 		2  short circuit (-32768)
                 		3  max. Tolerance exceede
                 		4  group switch turned off
                 		5  sensor error (if not open loop selected)
===================================================================*/

  /* Time base counter */
  LCCounter(&baseLCCounter);
  
	/***************************************start***************************************/
  	enables[0]= enable_0;
	actValues[0] = actValue_0;
	setValues[0] = setValue_0;
	highDeviations[0] = highDeviation_0;
	lowDeviations[0] = lowDeviation_0;
	/*
  	controlers[0].enable = enable_0;
  	controlers[0].actValue = actValue_0;
    controlers[0].sensorCorrection = sensorCorrection_0;
    controlers[0].setValue = setValue_0; 
	controlers[0].highDeviation = highDeviation_0;
	controlers[0].lowDeviation = lowDeviation_0;
	
  	*/
  	/*****************end end end end************************************************/

	for(i=0;i<zoneNumber;++i){
	
  /* PID tuning */
	  
  controlers[i].autoTuneControler.enable   = enable_0;
  controlers[i].autoTuneControler.okToStep = LCPIDTune_0.rdyToStep;
  controlers[i].autoTuneControler.request  = tuningRequest;
  controlers[i].autoTuneControler.basetime = baseLCCounter.mscnt;
  LCPIDTune(&controlers[i].autoTuneControler);
  
/* LCPIDTune function block call */

  if (controlers[i].autoTuneControler.state == LCPID_TUNE_STATE_FINISHED)
  {
    tuningRequest = LCPID_TUNE_REQU_OFF;
  }
  
  /* PID controller */
  controlers[i].controler.enable   = enables[i];
  controlers[i].controler.ident    = controlers[i].autoTuneControler.ident; /* ident of PIDTune -> provides parameters (Kp, Tn, Tv, ...) */
  controlers[i].controler.W        = setValues[i];
  controlers[i].controler.X        = extruderLCRSimModExt[i].y;
  controlers[i].controler.basetime = baseLCCounter.mscnt;
  LCPID(&controlers[i].controler);			/* LCPID function block call */

  manipulatedVar = controlers[i].controler.Y;
  /* Extruder simulation model */
  extruderLCRSimModExt[i].Alpha_h = (REAL)manipulatedVar / 327.67;
  LCRSimModExt(&extruderLCRSimModExt[i]);	/* LCRSimModExt function block call */
	 actValues[i] = extruderLCRSimModExt[i].y;
}
  /* Extruder simulation model */
 /* extruderLCRSimModExt.Alpha_h = (REAL)manipulatedVar / 327.67;
  LCRSimModExt(&extruderLCRSimModExt);	/* LCRSimModExt function block call */

 /* actValue_0 = extruderLCRSimModExt[0].y;*/
  
}
