/** INCLUDE Files **/
#include <bur/plctypes.h> /** IEC datatypes **/
#include "loopcont.h"     /** LoopCont Library **/
#include "loopconr.h"     /** LoopConR Library **/

/** Variable declarations **/
_LOCAL  LCCounter_typ                baseLCCounter;
_LOCAL  LCPID_typ                    LCPID_0;
_LOCAL  LCPIDTune_typ                LCPIDTune_0;
_LOCAL  LCRSimModExt_typ             extruderLCRSimModExt;
_LOCAL  INT                          setValue, actValue, manipulatedVar;
_LOCAL  BOOL                         start;
_LOCAL  UDINT                        tuningRequest;
_LOCAL  lcpid_tune_addpar_typ        addParameter;
_LOCAL  lcpid_tune_osc_options_typ   oscOptions;
_LOCAL  lcpid_tune_step_options_typ  stepOptions;
_LOCAL BOOL start_tune;
/* ====== INIT Part ======= */
_INIT void initialization(void)
{
  /* Init variables */
  setValue      = 1000;
  start         = 0;
 tuningRequest = LCPID_TUNE_REQU_OSCILLATE + LCPID_TUNE_REQU_DIR_POS + LCPID_TUNE_REQU_PID + LCPID_TUNE_REQU_OSC_1 + LCPID_TUNE_REQU_PER_3;
	
start_tune=0;	
  /* Parameters for PID tuning */
  LCPIDTune_0.Y_min          = 0;
  LCPIDTune_0.Y_max          = 32767;
  LCPIDTune_0.Y0             = 6300;
  LCPIDTune_0.Y1             = 11300;
  LCPIDTune_0.X0             = 250;
  LCPIDTune_0.X_min          = -10000;
  LCPIDTune_0.X_max          = 10000;
  LCPIDTune_0.P_manualAdjust = 0;
  LCPIDTune_0.I_manualAdjust = 0;
  LCPIDTune_0.D_manualAdjust = 0;
  LCPIDTune_0.pAddPar        = (lcpid_tune_addpar_typ*)&addParameter;
  LCPIDTune_0.pOptions_osc   = (lcpid_tune_osc_options_typ*)&oscOptions;
  LCPIDTune_0.pOptions_step  = (lcpid_tune_step_options_typ*)&stepOptions;

  /* Parameters for PID controller */
  LCPID_0.A        = 0;
  LCPID_0.Y_man    = 0;
  LCPID_0.Y_fbk    = 0;
  LCPID_0.hold_I   = 0;
  LCPID_0.out_mode = LCPID_OUT_MODE_AUTO;

  /* Parameters for extruder simulation model */
  extruderLCRSimModExt.enable   = 1;
  extruderLCRSimModExt.Tt_h     = 900000;	/* microseconds */
  extruderLCRSimModExt.Tt_c     = 500000;	/* microseconds */
  extruderLCRSimModExt.k_h      = 39;
  extruderLCRSimModExt.k_c      = 0.012;
  extruderLCRSimModExt.PT2_T1   = 5.0;
  extruderLCRSimModExt.PT2_T2   = 12.5;
  extruderLCRSimModExt.Temp_amb = 250;
  extruderLCRSimModExt.Temp_c   = 250;
  extruderLCRSimModExt.Alpha_c  = 0.0;
}

/* ======== CYCLIC Part ======= */
_CYCLIC void cyclicfunction(void)
{
  /* Time base counter */
  LCCounter(&baseLCCounter);

  /* PID tuning */
  LCPIDTune_0.enable   = start;
  LCPIDTune_0.okToStep = LCPIDTune_0.rdyToStep;
  
  LCPIDTune_0.basetime = baseLCCounter.mscnt;
  LCPIDTune(&LCPIDTune_0);		/* LCPIDTune function block call */

if(start_tune){
  LCPIDTune_0.request  = tuningRequest;
  if (LCPIDTune_0.state == LCPID_TUNE_STATE_FINISHED)
  {
  
    LCPIDTune_0.request = LCPID_TUNE_REQU_OFF;
    start_tune=0;
  }
  }
  
  /* PID controller */
  LCPID_0.enable   = start;
  LCPID_0.ident    = LCPIDTune_0.ident; /* ident of PIDTune -> provides parameters (Kp, Tn, Tv, ...) */
  LCPID_0.W        = setValue;
  LCPID_0.X        = actValue;
  LCPID_0.basetime = baseLCCounter.mscnt;
  LCPID(&LCPID_0);			/* LCPID function block call */

  manipulatedVar = LCPID_0.Y;

  /* Extruder simulation model */
  extruderLCRSimModExt.Alpha_h = (REAL)manipulatedVar / 327.67;
  LCRSimModExt(&extruderLCRSimModExt);	/* LCRSimModExt function block call */

  actValue = extruderLCRSimModExt.y;
}
