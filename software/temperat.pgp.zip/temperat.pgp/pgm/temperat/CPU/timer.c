#include <bur/plc.h>       /* macros for B&R PLC programming */
#include <bur/plctypes.h>
#include <standard.h>      /* prototypes for STANDARD-Library */

/* === variables declaration === */
_LOCAL TON_typ TON_01;      /* instance variable of TON */
_LOCAL BOOL input;         /* input */
_LOCAL TIME presetTime;    /* Time for switch on delay */

_LOCAL BOOL output;        /* output is input with an on switch delay
                              of presetTime */
_LOCAL TIME elapsedTime;   /* elapsed time since positive edge of input */

/* === init part of task === */
_INIT void init(void)
{
    /* set delay time */
    presetTime = 1200;  /* is 1.2 seconds, since TIME is
                           measured in milliseconds*/
}

/* === cyclic part of task === */
_CYCLIC void cyclic(void)
{
    /* set input parameters */
    TON_01.IN = input;
    TON_01.PT = presetTime;

    /* call TON with address of instance variable */
   /* TON(&TON_01);

    /* read output parameters */
    output = TON_01.Q;
    elapsedTime = TON_01.ET;
}

