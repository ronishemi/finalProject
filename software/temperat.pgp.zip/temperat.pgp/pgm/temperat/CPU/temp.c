
/** INCLUDE Files **/
#include <bur/plctypes.h> /** IEC datatypes **/
#include "dataobj.h"	  /**Data Objects Library **/
#include "loopcont.h"     /** LoopCont Library **/
#include "loopconr.h"     /** LoopConR Library **/
#include "sys_lib.h"     /** system lib **/
#include <plastlib.h>		  /*plastic lib*/
#include "asstring.h"     /** string lib **/
#include "Controler.h"    /** Controler + AutoTune**/
#include "Group.h"     	  /** group struct**/

#define SIZE 8

/** Variable declarations **/
_LOCAL  LCCounter_typ                baseLCCounter;
_LOCAL  skal_typ 					 skal_;            
_LOCAL  LCPID_typ                    LCPID_0;
_LOCAL  LCPIDTune_typ                LCPIDTune_0;
_LOCAL  LCRSimModExt_typ             extruderLCRSimModExt[SIZE];
_LOCAL  INT                          setValue, actValue, manipulatedVar;
_LOCAL  BOOL                         start;
_LOCAL  UDINT                        tuningRequest;
_LOCAL  lcpid_tune_addpar_typ        addParameter;
_LOCAL  lcpid_tune_osc_options_typ   oscOptions;
_LOCAL  lcpid_tune_step_options_typ  stepOptions;
_LOCAL INT zoneNumber,i; 
_GLOBAL UINT status,timeStep;
_LOCAL DatObjInfo_typ DatObjInfo_0;
_LOCAL DatObjCreate_typ	DatObjCreate_0;
_LOCAL DatObjWrite_typ	DatObjWrite_0;

_LOCAL int save,saveIndex,grp;
_LOCAL char *tmpStr1,*tmpStr;

/*****/
_LOCAL Group group[2];
/*one zone test */
_LOCAL Controler *controlers[80],*Ctr;
_GLOBAL INT pidPar_p_1,pidPar_i_1,pidPar_d_1;
_GLOBAL INT setValue_0,actValue_0,sensorCorrection_0,highDeviation_0,lowDeviation_0,barrelDelayTime,mouldDelayTime,coolDelayTime;
_GLOBAL BOOL enable_0;
_GLOBAL UINT maxDiffTemp_0,maxDiffTemp_1,maxDiffTemp_2,sensorErrorTimeOn,sensorErrorTimeReset;

/*machine*/
_GLOBAL BOOL start_tun,start_button,switch_on_cylinder;


/*****VAR for loop********/
_LOCAL INT setValues[SIZE],actValues[SIZE],sensorCorrections[SIZE],lowDeviations[SIZE],highDeviations[SIZE];
_LOCAL INT groupTurnOn[5],groupTurnOff[5];
_LOCAL BOOL enables[SIZE];


/* ====== INIT Part ======= */
void _INIT temp1INIT(void)
{

	 		status = TMP_alloc(sizeof(char), (void**)&tmpStr1);
              if(status != 0)
              {
                return;
              }
			status = TMP_alloc(sizeof(char), (void**)&tmpStr);
              if(status != 0)
              {
                return;
              }



       if(zoneNumber == 0) 
       {
              zoneNumber=1;
       }
       
       /* Allocate the runtime memory for the defined zones*/
       for(i=0;i<zoneNumber;++i)
       {
              status = TMP_alloc(sizeof(Controler), (void**)&controlers[i]);
              if(status != 0)
              {
                     controlers[i] = 0;
                     return;
              }
              
              memset(controlers[i], 0, sizeof(Controler));
       }      
       
       /* We store the runtime memory to data object, so it will remain after power failure
       // First we check if the data object exists. If it is exists we copy from it to the runtime memory.
       // If it does not exists, we will create it.*/
       for(i=0;i<zoneNumber;++i)
       {
              /* Build the name of the data object as CtrDat_0, CtrDat_1, ... CtrDat_8*/
              itoa(i, tmpStr1);
              strcpy(tmpStr, "CtrDat_");
              strcat(tmpStr, tmpStr1);
              
              /* Check if it exist*/
              DatObjInfo_0.enable = 1;
			  DatObjInfo_0.pName = tmpStr;
              DatObjInfo(&DatObjInfo_0);
              
              if (DatObjInfo_0.status == ERR_OK)
              {
                     /* Data object exist. Copy it to the runtime memory*/
                     memcpy(controlers[i], DatObjInfo_0.pDatObjMem, sizeof(Controler));
              }
              else /* Data object does not exists, we will create it now*/
              {
                     /* Create the data object*/
                     DatObjCreate_0.enable = 1;
                     DatObjCreate_0.grp = 0;
                     DatObjCreate_0.pName = tmpStr;
                     DatObjCreate_0.len = sizeof(Controler);
                     DatObjCreate_0.MemType = doUSRROM;
                     DatObjCreate_0.Option = 0;
                     DatObjCreate_0.pCpyData = controlers[i];
                     DatObjCreate(&DatObjCreate_0);
                     
                     /*initialize controlers*/
               /* Parameters for PID tuning */
  				controlers[i]->autoTuneControler.Y_min = 0;
  				controlers[i]->autoTuneControler.Y_max = 32767;
  				controlers[i]->autoTuneControler.Y0    = 6300;
  				controlers[i]->autoTuneControler.Y1    = 11300;
  				controlers[i]->autoTuneControler.X0    = 250;
  				controlers[i]->autoTuneControler.X_min = -10000;
  				controlers[i]->autoTuneControler.X_max = 10000;
  				controlers[i]->autoTuneControler.P_manualAdjust = 0;
 				controlers[i]->autoTuneControler.I_manualAdjust = 0;
  				controlers[i]->autoTuneControler.D_manualAdjust = 0;
  				controlers[i]->autoTuneControler.pAddPar  = (lcpid_tune_addpar_typ*)&addParameter;
  				controlers[i]->autoTuneControler.pOptions_osc  = (lcpid_tune_osc_options_typ*)&oscOptions;
  				controlers[i]->autoTuneControler.pOptions_step  = (lcpid_tune_step_options_typ*)&stepOptions;

  			/* Parameters for PID controller */
  				controlers[i]->controler.A        = 0;
  				controlers[i]->controler.Y_man    = 0;
 				controlers[i]->controler.Y_fbk    = 0;
  				controlers[i]->controler.hold_I   = 0;
  				controlers[i]->controler.out_mode = LCPID_OUT_MODE_AUTO;

			/* Parameters for extruder simulation model */
  				extruderLCRSimModExt[i].enable   = 1;
  				extruderLCRSimModExt[i].Tt_h     = 900000;	/* microseconds */
  				extruderLCRSimModExt[i].Tt_c     = 500000;	/* microseconds */
  				extruderLCRSimModExt[i].k_h      = 39;
  				extruderLCRSimModExt[i].k_c      = 0.012;
  				extruderLCRSimModExt[i].PT2_T1   = 5.0;
  				extruderLCRSimModExt[i].PT2_T2   = 12.5;
  				extruderLCRSimModExt[i].Temp_amb = 250;
  				extruderLCRSimModExt[i].Temp_c   = 250;
  				extruderLCRSimModExt[i].Alpha_c  = 0.0;

              }
       }

       save = 0;       /* Set to 1 to copy the runtime controlers to the data object (flash memory)*/
       saveIndex = 0;
}

void _CYCLIC temp1CYCLIC(void)
{


       /* Use controls[i] for manipulation of the process
       
       // If you want to store the runtime data to flash, set the save variable to 1*/
       if (save)
       {
              save = 0;
              saveIndex = 1;
       }
       
       /* We write one controler[i] in each cycle, so it will not cause a time violation*/
       if (saveIndex > 0)
       {
              i = saveIndex - 1;
              
              /* Build the data object name*/
              itoa(i, tmpStr1);
              strcpy(tmpStr, "CtrDat_");
              strcat(tmpStr, tmpStr1);
              
              /* Get the ident of the data object*/
              DatObjInfo_0.enable = 1;
              DatObjInfo_0.pName = tmpStr;
              DatObjInfo(&DatObjInfo_0);
              
              if (DatObjInfo_0.status == ERR_OK)
              {
                     /* Copy the controler[i] to the data object*/
                     DatObjWrite_0.enable = 1;
                     DatObjWrite_0.ident = DatObjInfo_0.ident;
                     DatObjWrite_0.Offset = 0;
                     DatObjWrite_0.pSource = controlers[i];
                     DatObjWrite_0.len = sizeof(Controler);
                     DatObjWrite(&DatObjWrite_0);
              }
       
              /* Increment to the next controler*/
              saveIndex++;
              
              /* Check if we save all controlers*/
              if (saveIndex > zoneNumber)
              {
                     /* We finish the save process*/
                     saveIndex = 0;
              }
       }


/*============================================================================
                HEATING ORGANIZATION
  ============================================================================
***************************************************************

Function:  Heating Organisation
           Sensor Checking
           Tolerance checking
           Soft start
           Controller selection and optimization

Group numbers:   0  barrel  
                 1  mould heating
                 2  "cooling"
                
controlers[].enable:  	on/off
controlers[].contType 	0  switch off
						1  heating PID
                 		2  heating PID for hotrunner (with soft start allowed)
                		3  open loop
                 		4: Autotuning
                 		
group[].error[]:    	 0  max. Tolerance exceede
   						 1  min. Tolerance exceede	
                 		 2  maximum allowed temperature
                 		 3  short circuit (-32768)
                 		 4  sensor error (if not open loop selected)
                 		 5  output is not changing (frozen)

===================================================================*/

  /* Time base counter */
  LCCounter(&baseLCCounter);
  
  /*  initialize*/
  /**alarm times*/
  sensorErrorTimeOn = 20;				/*20 sec delay befor sensor error*/
  sensorErrorTimeReset = 10;			/*10 sec delay befor sensor error reset*/
  
   /*max temperature for group*/
  group[0].maxTemperature = 3000;		/*barrel*/
  group[1].maxTemperature = 3000;		/*mould*/
  group[2].maxTemperature = 1000;		/*cooling*/
   
   /*min temparature for group*/
    group[0].minTemperature = 10;		/*barrel*/
  	group[1].minTemperature = 10;		/*mould*/
  	group[2].minTemperature = 10;		/*cooling*/
	
	/*cycle time for group*/
    group[0].setCycleTime = 100000;		/*barrel 100mSEC*/
  	group[1].setCycleTime = 10000;		/*mould 10mSEC*/
  	group[2].setCycleTime = 500000;		/*cooling 500mSEC*/
	
	/*delay time start count after all controllers are above low Deviation*/
    group[0].delayTime = barrelDelayTime;		/*barrel*/
  	group[1].delayTime = mouldDelayTime;		/*mould*/
  	group[2].delayTime = coolDelayTime;		/*cooling*/
	
	/*max difference between two zones*/
    group[0].maxDiffTemp = maxDiffTemp_0;		/*barrel*/
  	group[1].maxDiffTemp = maxDiffTemp_1;		/*mould*/
  	group[2].maxDiffTemp = maxDiffTemp_2;		/*cooling*/

  
	/***************************************start***************************************/
	timeStep = 10;					/*x sec to increase time */ 
  	enables[0]= enable_0;
	actValues[0] = actValue_0;
	setValues[0] = setValue_0;
	highDeviations[0] = highDeviation_0;
	lowDeviations[0] = lowDeviation_0;
	/*
  	controlers[0].enable = enable_0;
  	controlers[0].actValue = actValue_0;
    controlers[0].sensorCorrection = sensorCorrection_0;
    controlers[0].setValue = setValue_0; 
	controlers[0].highDeviation = highDeviation_0;
	controlers[0].lowDeviation = lowDeviation_0;
	
  	*/
  	/*****************end end end end************************************************/
  	/************start copy from 140*/
  	
  	
  	 /**************************start insert here************************************/
 i=0;   
do
{
   Ctr = (controlers[i]);
   		/* change output to precentages*/
   			skal_.in = Ctr -> outPut;
            skal_.inmin = -32768;
            skal_.inmax = 32767;
            skal_.outmin = 0;
            skal_.outmax = 100;
            skal(&skal_);
            Ctr ->precentageOutPut = skal_.out; /*;% output*/
      /*sensor correction*/      
		Ctr -> actValue = actValues[i] + Ctr -> sensorCorrection;


   grp = Ctr -> groupNum;     

   if (Ctr -> enable) 
   { 
                    		

     /*;=====================================================================
     ;SENSOR ERROR CHECKING:
     ;=====================================================================*/
     if (Ctr -> contType != 3)                /* Set Error - Bit if sensor error, not in open loop */
     {
        if (Ctr -> actValue > 7500)             /* Check for Sensor Error*/
        {
          Ctr -> actValue = 7500;                    /* Temperature value for VIS*/
          Ctr -> checkSensorDefect = 1;
        }
        else                                   /* No sensor error*/
        {
          Ctr -> checkSensorDefect = 0;
          Ctr -> controler.X = Ctr -> actValue;               /* New temperature */
        };

        /*;===========================================================
        ; the counter has reached limit, the group is on and the zone*
        ; is on ----> set sensor error 
        ;===========================================================*/
        if (Ctr -> checkSensorDefect == 1) 
        {
            if (Ctr -> sensorErrorTimeOn < sensorErrorTimeOn) 
              ++Ctr -> sensorErrorTimeOn ;
           else 
           {
              group[grp].error[4] = i+1;          	/* Sensor brak bit of group*/
					
           };
        }
        else
        {
           Ctr -> sensorErrorTimeOn = 0;        
           
        };
       /* group[grp].error[5]= group[grp].error[5] > 0 ? group[grp].error[5] : Ctr ->error[5];*/
       
     };
   };                                        
		
     /*;==================================
     ;Check for max. allowed Temperature 
     ;==================================*/
     if (Ctr -> actValue > group[grp].maxTemperature)    /*;*** Switch off whole grp*/
     {
      group[grp].error[2] = i+1;    /*;*** zone number --> additional info*//*shemi*/
           /*;Ctr -> Pbon=0  ;switch off zone where max-temp exceeded*/
     };
     
   /*  group[grp].error[1] = group[grp].error[1] > 0 ? group[grp].error[1] : Ctr ->error[1]  ;
        /* H__.P_grp[grp].Mbmax = Mbmax_loc[grp];        /*;if only one zone above max--> set max-marker for group  here needs change 23/5/2013*/
	 /*;===================================================
     ;Check for max tolerance
     ;===================================================*/
		if (Ctr -> actValue > Ctr ->maxTol)
		{
			group[grp].error[0] = i+1;
		
		}
	/*;===================================================
     ;Check for min tolerance
     ;===================================================*/
		if (Ctr -> actValue < Ctr ->minTol)
		{
			group[grp].error[1] = i+1;
		
		}

	

     /*;===================================================
     ;Check for "freezing" of actual value during heating
     ;===================================================*/
     switch( Ctr -> contType )  
     {       
                
        case 1:
        case 2:   /*;control with act. temp. signal is active*/
        {
        	
           if (Ctr -> precentageOutPut == 100)                  /*;100 % ED*/
              Ctr -> checkFreezing = 1;
           else
              Ctr -> checkFreezing = 0;
              
       		
			Ctr ->freezTime=Ctr ->freezTime+ timeStep;			/*add time to freezing*/	
          if(group[grp].freezingTime>=Ctr ->freezTime)
          {    
           if (Ctr -> controler.X-5 <= Ctr -> freezTemperature)           /*;temperature falling or equal*/
              Ctr -> controlFreezed = 1;
           else
              Ctr -> controlFreezed = 0;
              Ctr -> freezTemperature = Ctr -> actValue;
           Ctr ->freezTime=0;
          }
        
       if(!start_tun&&!start_button&&switch_on_cylinder)
		{        
        
                 
           	if ((Ctr -> checkFreezing == 1) && (Ctr -> controlFreezed == 1)) 
           	{
           		/*delay time = 600000*/
            	  if (Ctr -> actFreezingTime < group[grp].freezingTime)         /*;10 minutes 100% ED and temperature falling or equal*/
                	 Ctr ->actFreezingTime = Ctr ->actFreezingTime + timeStep;
              		else 
                		 group[grp].error[5] = i+1;    /* freezing alarm bit of group on*/
          	}   
           		else Ctr ->actFreezingTime=0;               /*;*** Reset counter for time*/
        }
        else Ctr ->actFreezingTime=0; 
        
          /*;======================================================
          ;on AT660, a temperature of -32768 indicates that:
          ;a) not valid sensor type adjusted
          ;b) the voltage from sensor < (voltage measurement range) or (range of sensor)
          ;c) comparator temperature out of range
          ;====================================================== */
          if (Ctr -> controler.X == -32768)            /*;short circuit detection from AT660*/
          {
            /* Ctr -> Pbon = 0;*/
             group[grp].error[3]  = i+1;      /*;additional info: channel no.*/
             
         };
			break;
          
        };
       
    }; 
   i=i+1;
}
while( i < zoneNumber);                         /* ;all controllers checked*/

  /**************************end insert here************************************/


  for(i=0;i<zoneNumber;++i){
	
  /* PID tuning */
	  
  controlers[i]->autoTuneControler.enable   = 	enables[i];
  controlers[i]->autoTuneControler.okToStep = LCPIDTune_0.rdyToStep;
  controlers[i]->autoTuneControler.request  = tuningRequest;
  controlers[i]->autoTuneControler.basetime = baseLCCounter.mscnt;
  LCPIDTune(&controlers[i]->autoTuneControler);
  
/* LCPIDTune function block call */

  if (controlers[i]->autoTuneControler.state == LCPID_TUNE_STATE_FINISHED)
  {
    tuningRequest = LCPID_TUNE_REQU_OFF;
  }
  
  /* PID controller */
  controlers[i]->controler.enable   = enables[i];
  controlers[i]->controler.ident    = controlers[i]->autoTuneControler.ident; /* ident of PIDTune -> provides parameters (Kp, Tn, Tv, ...) */
  controlers[i]->controler.W        = setValues[i];
  controlers[i]->controler.X        = extruderLCRSimModExt[i].y;
  controlers[i]->controler.basetime = baseLCCounter.mscnt;
  LCPID(&controlers[i]->controler);			/* LCPID function block call */

  manipulatedVar = controlers[i]->controler.Y;
  /* Extruder simulation model */
  extruderLCRSimModExt[i].Alpha_h = (REAL)manipulatedVar / 327.67;
  LCRSimModExt(&extruderLCRSimModExt[i]);	/* LCRSimModExt function block call */
	 actValues[i] = extruderLCRSimModExt[i].y;
}		
		
}














